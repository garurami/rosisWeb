package rosis.web.vo;

public class SolutionVO {
	
	private String solutionNm;
	private String solutionImageSrc;
	
	public String getSolutionNm() {
		return solutionNm;
	}
	
	public void setSolutionNm(String solutionNm) {
		this.solutionNm = solutionNm;
	}
	
	public String getSolutionImageSrc() {
		return solutionImageSrc;
	}
	
	public void setSolutionImageSrc(String solutionImageSrc) {
		this.solutionImageSrc = solutionImageSrc;
	}
	
}
