package rosis.web.vo;

public class DeptVO {

	private String deptNm;
	
	public DeptVO(String deptNm) {
		this.deptNm = deptNm;
	}
	
	public String getDeptNm() {
		return deptNm;
	}

	public void setDeptNm(String deptNm) {
		this.deptNm = deptNm;
	}
	
}
